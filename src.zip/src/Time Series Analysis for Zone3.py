# ===============================================
# 🔍 TIME SERIES ANALYSIS FOR ZONE 3
# ===============================================

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from statsmodels.tsa.seasonal import seasonal_decompose
from statsmodels.graphics.tsaplots import plot_acf, plot_pacf
from statsmodels.tsa.stattools import adfuller
from statsmodels.stats.diagnostic import acorr_ljungbox
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from statsmodels.tsa.statespace.sarimax import SARIMAX
import warnings
warnings.filterwarnings("ignore")

# =============================
# 1️⃣ Loading Data
# =============================
df = pd.read_csv("zone3.csv")
df['Datetime'] = pd.to_datetime(df['Datetime'], errors='coerce')
df = df.set_index('Datetime').sort_index()

# =============================
# 2️⃣ Choosing Target Series
# =============================
target_col = 'PowerConsumption_Zone3'
if target_col not in df.columns:
    raise ValueError(f"Target column not found: {target_col}")

# Downsample 10-minute data to 1-hour averages
series = df[target_col].resample('1H').mean().interpolate(method='time')

# Convert the resampled series to a DataFrame
df_resampled = series.to_frame(name=target_col)

print("\n🧭 Extracting temporal/seasonal features from the timestamp...\n")

df_resampled['hour'] = df_resampled.index.hour
df_resampled['dayofweek'] = df_resampled.index.dayofweek
df_resampled['month'] = df_resampled.index.month
df_resampled['is_weekend'] = (df_resampled.index.dayofweek >= 5).astype(int)

# Month-to-season mapping
def get_season(month):
    if month in [12, 1, 2]:
        return "Winter"
    elif month in [3, 4, 5]:
        return "Spring"
    elif month in [6, 7, 8]:
        return "Summer"
    else:
        return "Autumn"

df_resampled['season'] = df_resampled['month'].apply(get_season)

print("📅 Extracted Features:")
print(df_resampled[['hour', 'dayofweek', 'month', 'is_weekend', 'season']].head())
print("\n✅ Time-based feature extraction completed.\n")

print(f"\n📈 Examined Series: {target_col}")
print(f"Data Range: {series.index.min()} → {series.index.max()}")
print(f"Total Data Points: {len(series)}")

# =============================
# 3️⃣ Trend & Seasonality Analysis
# =============================
try:
    period = 24 if len(series) > 48 else max(2, len(series)//2)
    result = seasonal_decompose(series, model='additive', period=period)
    result.plot()
    plt.suptitle(f"{target_col} - Trend & Seasonality Analysis", fontsize=14)
    plt.show()
except Exception as e:
    print(f"⚠️ Seasonal decomposition failed: {e}")
    result = None

# =============================
# 4️⃣ Rolling Mean & Std (Stationarity Observation)
# =============================
rolling_mean = series.rolling(window=24, min_periods=1).mean()
rolling_std = series.rolling(window=24, min_periods=1).std()

plt.figure(figsize=(12,5))
plt.plot(series, label='Original Series')
plt.plot(rolling_mean, color='red', label='Moving Average (24 hour)')
plt.plot(rolling_std, color='green', label='Moving Std (24 hour)')
plt.title(f"{target_col} - Visuzalization of Stationary")
plt.legend()
plt.show()

# =============================
# 5️⃣ ADF (Augmented Dickey-Fuller) Test
# =============================
print("\n🧪 [ADF TEST] Checking stationarity of the original series...\n")
adf_result = adfuller(series.dropna())

print("📊 ADF Test Results (Original Series)")
print("----------------------------------------")
print(f"ADF Test Statistic : {adf_result[0]:.4f}")
print(f"p-value             : {adf_result[1]:.4f}")
print("Critical Values:")
for key, value in adf_result[4].items():
    print(f"   {key}: {value:.4f}")

if adf_result[1] >= 0.05:
    print("\n⚠️ Result: Series is not stationary (p ≥ 0.05).")
    print("📉 Perform first-order differencing on the series.\n")

# =============================
# 6️⃣ Differencing
# =============================
if adf_result[1] >= 0.05:
    series_diff = series.diff().dropna()

    plt.figure(figsize=(12,5))
    plt.plot(series_diff, label='First-Order Differentiated Series', color='purple')
    plt.title(f"{target_col} - After First-Order Differentiation")
    plt.legend()
    plt.show()

    print("🧪 [ADF TEST] Stability control of the differentiated series...\n")
    adf_result_diff = adfuller(series_diff)

    print("📊 ADF Test Results (First-Order Differentiated Series)")
    print("----------------------------------------")
    print(f"ADF Test Statistic : {adf_result_diff[0]:.4f}")
    print(f"p-value             : {adf_result_diff[1]:.4f}")
    print("Critical Values:")
    for key, value in adf_result_diff[4].items():
        print(f"   {key}: {value:.4f}")

    if adf_result_diff[1] < 0.05:
        print("\n✅ The series became stationary after differentiation (p < 0.05).")
    else:
        print("\n⚠️ The series is still not stable. Second differentiation is necessary.")

    series_final = series_diff.copy()
else:
    print("\n✅ The series is already stationary (p < 0.05). No difference detection is necessary.")
    series_final = series.copy()

# =============================
# 7️⃣ Autocorrelation & Partial Autocorrelation
# =============================
plt.figure(figsize=(12,4))
plot_acf(series_final.dropna(), lags=48)
plt.title(f"{target_col} - Autocorrelation (ACF)")
plt.show()

plt.figure(figsize=(12,4))
plot_pacf(series_final.dropna(), lags=48)
plt.title(f"{target_col} - Partial Autocorrelation (PACF)")
plt.show()

# =============================
# 8️⃣ Ljung-Box Test
# =============================
lb_test = acorr_ljungbox(series_final.dropna(), lags=[24], return_df=True)

print("\n🧮 Ljung-Box Test Results (Lag of 24 hours)")
print("----------------------------------------")
print(lb_test)

p_value = lb_test['lb_pvalue'].values[-1]
if p_value < 0.05:
    print("\n⚠️ Result: There is evidence of significant autocorrelation in the series (p < 0.05).")
else:
    print("\n✅ Result: There is no evidence of significant autocorrelation in the series (p ≥ 0.05).")

# =============================
# 9️⃣ Summary Report
# =============================
if result:
    trend_strength = np.var(result.trend.dropna()) / np.var(series.dropna())
    seasonal_strength = np.var(result.seasonal.dropna()) / np.var(series.dropna())
else:
    trend_strength = seasonal_strength = np.nan

print("\n📊 Summary Report")
print("----------------------------------------")
print(f"Trend Strength       : {trend_strength:.3f}")
print(f"Seasonality Strength: {seasonal_strength:.3f}")
print(f"Original ADF p-value : {adf_result[1]:.4f}")
print("----------------------------------------")

if trend_strength > 0.1:
    print("↗️ A clear trend is present.")
if seasonal_strength > 0.1:
    print("🔁 Strong seasonality is observed.")
if adf_result[1] >= 0.05:
    print("📉 First-order differencing was applied because the series was not stationary.")

print("\n✅ Analyze completed.")
print("Based on this information, we can select an appropriate time series model (SARIMA, Prophet, LSTM, etc.)")

# =============================================
# 🔍 10️⃣ Clustering-Based Anomaly Detection (KMeans)
# =============================================
print("\n🔍 Starting clustering-based anomaly detection...\n")

data_for_clustering = series_final.copy().to_frame(name='value')
data_for_clustering['lag1'] = data_for_clustering['value'].shift(1)
data_for_clustering['lag2'] = data_for_clustering['value'].shift(2)
data_for_clustering['diff1'] = data_for_clustering['value'].diff(1)
data_for_clustering = data_for_clustering.dropna()

scaler = StandardScaler()
X_scaled = scaler.fit_transform(data_for_clustering)

kmeans = KMeans(n_clusters=3, n_init=10, random_state=42)
data_for_clustering['cluster'] = kmeans.fit_predict(X_scaled)

distances = kmeans.transform(X_scaled)
data_for_clustering['distance_to_center'] = np.min(distances, axis=1)

threshold = np.percentile(data_for_clustering['distance_to_center'], 95)
data_for_clustering['is_anomaly'] = data_for_clustering['distance_to_center'] > threshold

plt.figure(figsize=(14,6))
plt.plot(data_for_clustering.index, data_for_clustering['value'], label='Series', alpha=0.7)
plt.scatter(
    data_for_clustering.index[data_for_clustering['is_anomaly']],
    data_for_clustering['value'][data_for_clustering['is_anomaly']],
    color='red', label='Anomaly Points'
)
plt.title(f"{target_col} - Clustering-Based Anomaly Detection (KMeans)")
plt.legend()
plt.show()

print("\n📊 Anomaly Detection Summary")
print("----------------------------------")
print(f"Total Point: {len(data_for_clustering)}")
print(f"Number of Anomalies: {data_for_clustering['is_anomaly'].sum()}")
print(f"Anomaly Ratio: {100 * data_for_clustering['is_anomaly'].mean():.2f}%")
print("----------------------------------")

print("\n✅ Clustering-Based Anomaly Detection completed.")

# =============================================
# 🧹 11️⃣ Anomaly Cleaning (Neighbor Mean Method)
# =============================================
print("\n🧹 Starting anomaly cleaning using the neighbor mean method...\n")

cleaned_series = data_for_clustering.copy()
cleaned_series['clean_value'] = cleaned_series['value']

# Replace each anomaly with the average of the previous and next values
for idx in cleaned_series[cleaned_series['is_anomaly']].index:
    prev_time = idx - pd.Timedelta(hours=1)
    next_time = idx + pd.Timedelta(hours=1)

    prev_val = cleaned_series.loc[prev_time, 'value'] if prev_time in cleaned_series.index else np.nan
    next_val = cleaned_series.loc[next_time, 'value'] if next_time in cleaned_series.index else np.nan

    mean_val = np.nanmean([prev_val, next_val])
    if not np.isnan(mean_val):
        cleaned_series.loc[idx, 'clean_value'] = mean_val

# Visual Comparision
plt.figure(figsize=(14,6))
plt.plot(cleaned_series.index, cleaned_series['value'], label='Original Series', alpha=0.4)
plt.plot(cleaned_series.index, cleaned_series['clean_value'], label='Cleaned Series', color='green')
plt.scatter(
    cleaned_series.index[cleaned_series['is_anomaly']],
    cleaned_series['value'][cleaned_series['is_anomaly']],
    color='red', label='Anomaly (Fixed)'
)
plt.title(f"{target_col} - Anomaly Cleaning with Neighbor Mean")
plt.legend()
plt.show()

# Summary information
n_anomalies = cleaned_series['is_anomaly'].sum()
print("\n📊 Anomaly Cleaning Summary")
print("----------------------------------")
print(f"Number of Corrected Anomalies : {n_anomalies}")
print(f"Remaining Data Points        : {len(cleaned_series)}")
print("----------------------------------")
print("\n✅ Anomaly cleaning using the neighbor mean method completed.\n")

# Cleaned series (ready for modeling)
series_cleaned_zone3 = cleaned_series['clean_value'].copy()

from statsmodels.tsa.stattools import adfuller

print("\n🧪 [ADF TEST] Is the cleaned series in Zone 3 stationary?\n")
adf_result = adfuller(series_cleaned_zone3.dropna())

print("📊 ADF Test Results (Cleaned Series - Zone 3)")
print("----------------------------------------")
print(f"ADF Test Statistic : {adf_result[0]:.4f}")
print(f"p-value             : {adf_result[1]:.4f}")
print("Critical Values:")
for key, value in adf_result[4].items():
    print(f"   {key}: {value:.4f}")

if adf_result[1] < 0.05:
    print("\n✅ Series is Stationary (p < 0.05). Suitable for SARIMA.")
else:
    print("\n⚠️ Series is not Stationary (p ≥ 0.05). Differencing will be applied.")

# =============================================
# 🚀 SARIMA – Zone 3
# =============================================

import optuna
from statsmodels.tsa.statespace.sarimax import SARIMAX
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import warnings
warnings.filterwarnings("ignore")

# ======================
# 1️⃣ Auxiliary Functions
# ======================
def evaluate_forecast(y_true, y_pred, metric="mae"):
    if metric == "mae":
        return mean_absolute_error(y_true, y_pred)
    elif metric == "mse":
        return mean_squared_error(y_true, y_pred)
    elif metric == "r2":
        return r2_score(y_true, y_pred)
    else:
        raise ValueError("Unsupported metric")


def optimize_time_series_split(series, metric="mae", n_trials=20, test_size_range=(0.1, 0.4),
                               order=(1,0,1), seasonal_order=(1,1,1,24)):
    """
    Find the best train/test ratio for the time series with Optuna.
    """
    results = []

    def objective(trial):
        test_size = trial.suggest_float("test_size", test_size_range[0], test_size_range[1])
        split_index = int(len(series) * (1 - test_size))
        train, test = series.iloc[:split_index], series.iloc[split_index:]
        if len(test) < 24:  # çok kısa test seti olmasın
            return np.inf

        try:
            model = SARIMAX(train,
                            order=order,
                            seasonal_order=seasonal_order,
                            enforce_stationarity=False,
                            enforce_invertibility=False)
            fitted = model.fit(disp=False)
            forecast = fitted.forecast(steps=len(test))
            score = evaluate_forecast(test, forecast, metric)
        except Exception:
            score = np.inf

        results.append((test_size, score))
        return score  # minimize (lower error is better)

    study = optuna.create_study(direction="minimize", sampler=optuna.samplers.TPESampler(seed=42))
    study.optimize(objective, n_trials=n_trials, show_progress_bar=True)

    best_trial = study.best_trial
    best_test_size = best_trial.params["test_size"]

    print(f"\n✅ Best test ratio: {best_test_size:.3f}")
    print(f"📉 The best {metric.upper()} score: {best_trial.value:.4f}")

    # Görselleştirme
    df_results = pd.DataFrame(results, columns=["test_size", metric])
    df_results = df_results.groupby("test_size").mean().reset_index()

    plt.figure(figsize=(8, 5))
    plt.plot(df_results["test_size"], df_results[metric], marker="o")
    plt.axvline(best_test_size, color="red", linestyle="--", label=f"Best split = {best_test_size:.3f}")
    plt.xlabel("Test size ratio")
    plt.ylabel(metric.upper())
    plt.title(f"Optuna Time Series Split Optimization ({metric})")
    plt.legend()
    plt.grid(True)
    plt.show()

    return best_test_size, df_results


# ======================
# 2️⃣ SARIMA Modeli ve Optimizasyon
# ======================
series = series_cleaned_zone3  # cleaned, hourly series

print("\n🔹 [SARIMA] We are searching for the best train/test ratio with Optuna...\n")

best_test_size, optimization_df = optimize_time_series_split(
    series,
    metric="mae",            # "mae" | "mse" | "r2"
    n_trials=15,
    test_size_range=(0.1, 0.4),
    order=(1,0,1),
    seasonal_order=(1,1,1,24)
)

# ======================
# 3️⃣ Train the Final Model with the Best Split
# ======================
split_index = int(len(series) * (1 - best_test_size))
train, test = series.iloc[:split_index], series.iloc[split_index:]

print(f"\n📊 Train size: {len(train)} | Test size: {len(test)} ({best_test_size:.2f} test ratio)\n")

model_zone3 = SARIMAX(train,
                      order=(1,0,1),
                      seasonal_order=(1,1,1,24),
                      enforce_stationarity=False,
                      enforce_invertibility=False)

results_zone3 = model_zone3.fit(disp=False)
forecast_zone3 = results_zone3.get_forecast(steps=len(test))
forecast_mean = forecast_zone3.predicted_mean
forecast_ci = forecast_zone3.conf_int()

# ======================
# 4️⃣ Performance Evaluation
# ======================
mae = mean_absolute_error(test, forecast_mean)
mse = mean_squared_error(test, forecast_mean)
r2 = r2_score(test, forecast_mean)

print("📈 Model Performance (Test Set)")
print("--------------------------------")
print(f"MAE : {mae:.4f}")
print(f"MSE : {mse:.4f}")
print(f"R²  : {r2:.4f}")

# ======================
# 5️⃣ Visualization
# ======================
plt.figure(figsize=(14,6))
plt.plot(train.index, train, label="Train", alpha=0.6)
plt.plot(test.index, test, label="Test (actual)", color="blue")
plt.plot(test.index, forecast_mean, label="SARIMA Forecast", color="orange")
plt.fill_between(test.index,
                 forecast_ci.iloc[:,0],
                 forecast_ci.iloc[:,1],
                 color='orange', alpha=0.3)
plt.title(f"Zone 3 - SARIMA (Best Split {best_test_size:.2f})")
plt.legend()
plt.show()
