# ===============================================
# optuna_time_series_split_optimizer.py
# ===============================================
import optuna
import numpy as np
import pandas as pd
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from statsmodels.tsa.statespace.sarimax import SARIMAX
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings("ignore")


def evaluate_forecast(y_true, y_pred, metric="mae"):
    if metric == "mae":
        return mean_absolute_error(y_true, y_pred)
    elif metric == "mse":
        return mean_squared_error(y_true, y_pred)
    elif metric == "r2":
        return r2_score(y_true, y_pred)
    else:
        raise ValueError("Unsupported metric")


def optimize_time_series_split(series, metric="mae", n_trials=20, test_size_range=(0.1, 0.4), order=(1,0,1), seasonal_order=(1,1,1,24)):
    """
    Finds the best train/test ratio for the time series.
    series: pandas Series (date-indexed)
    metric: optimize edilecek metrik ("mae", "mse", "r2")
    test_size_range: (min, max) oran aralığı
    """
    results = []

    def objective(trial):
        test_size = trial.suggest_float("test_size", test_size_range[0], test_size_range[1])
        split_index = int(len(series) * (1 - test_size))

        train, test = series.iloc[:split_index], series.iloc[split_index:]
        if len(test) < 10:  # çok küçük test setlerinden kaçın
            return np.inf

        try:
            model = SARIMAX(train,
                            order=order,
                            seasonal_order=seasonal_order,
                            enforce_stationarity=False,
                            enforce_invertibility=False)
            results_fit = model.fit(disp=False)
            forecast = results_fit.forecast(steps=len(test))
            score = evaluate_forecast(test, forecast, metric)
        except Exception as e:
            score = np.inf

        results.append((test_size, score))
        return score  # minimize (lower error is better)

    study = optuna.create_study(direction="minimize", sampler=optuna.samplers.TPESampler(seed=42))
    study.optimize(objective, n_trials=n_trials, show_progress_bar=True)

    best_trial = study.best_trial
    best_test_size = best_trial.params["test_size"]

    print(f"\n✅ Best test ratio: {best_test_size:.3f}")
    print(f"📉 The best {metric.upper()} score: {best_trial.value:.4f}")

    # Görselleştirme
    df_results = pd.DataFrame(results, columns=["test_size", metric])
    df_results = df_results.groupby("test_size").mean().reset_index()

    plt.figure(figsize=(8, 5))
    plt.plot(df_results["test_size"], df_results[metric], marker="o")
    plt.axvline(best_test_size, color="red", linestyle="--", label=f"Best split = {best_test_size:.3f}")
    plt.xlabel("Test size ratio")
    plt.ylabel(metric.upper())
    plt.title(f"Optuna Time Series Split Optimization ({metric})")
    plt.legend()
    plt.grid(True)
    plt.show()

    return best_test_size, df_results


