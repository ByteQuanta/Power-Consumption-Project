import pandas as pd

# Read to Main csv file
df = pd.read_csv("your csv file's path/powerconsumption.csv")

# For Zone 3
df_zone1 = df.drop(columns=['PowerConsumption_Zone2', 'PowerConsumption_Zone3'])
df_zone1.to_csv('zone1.csv', index=False)

# For Zone 3
df_zone2 = df.drop(columns=['PowerConsumption_Zone1', 'PowerConsumption_Zone3'])
df_zone2.to_csv('zone2.csv', index=False)

# For Zone 3
df_zone3 = df.drop(columns=['PowerConsumption_Zone1', 'PowerConsumption_Zone2'])
df_zone3.to_csv('zone3.csv', index=False)

print("✅ Zone1, Zone2 ve Zone3 files created!")


